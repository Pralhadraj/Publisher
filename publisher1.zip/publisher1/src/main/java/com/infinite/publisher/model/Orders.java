package com.infinite.publisher.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Orders {
	
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer id;
    @Column(name = "date")
    private Double date;
    @Column(name = "purchaser_id")
    private Integer purchaser_id;
    
    @Column(name = "quantity")
    private Integer quantity;
    
    @Column(name = "product_id")
    private Integer product_id;
    
public Orders() {
	
}

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public Double getDate() {
	return date;
}

public void setDate(Double date) {
	this.date = date;
}

public Integer getPurchaser_id() {
	return purchaser_id;
}

public void setPurchaser_id(Integer purchaser_id) {
	this.purchaser_id = purchaser_id;
}

public Integer getQuantity() {
	return quantity;
}

public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}

public Integer getProduct_id() {
	return product_id;
}

public void setProduct_id(Integer product_id) {
	this.product_id = product_id;
}

    
}

