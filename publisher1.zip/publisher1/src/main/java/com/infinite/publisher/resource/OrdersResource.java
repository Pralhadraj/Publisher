package com.infinite.publisher.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.publisher.model.Orders;
import com.infinite.publisher.repository.OrdersRepository;

import antlr.collections.List;

@RestController
@RequestMapping(value =  "/rest/orders")
public class OrdersResource {
	 	@Autowired
	    OrdersRepository ordersRepository;
	
	@GetMapping(value = "/all")
    public java.util.List<Orders> getAll() {
        return ordersRepository.findAll();
    }

    @PostMapping(value = "/load")
    public java.util.List<Orders> persist(@RequestBody final Orders orders) {
        ordersRepository.save(orders);
        return ordersRepository.findAll();
        
    }
	

}
